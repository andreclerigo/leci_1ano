public class Box
{
   private double height;
   private double width;
   private double depth;
   private double volume;
   private double surfaceArea;

   /**
      Constructs a box with a given side length.
      @param sideLength the length of each side
   */   
   public Box(double h, double w, double d)
   {
      height = h;
      width = w;
      depth = d;
   }

   /**
      Gets the volume of this box.
      @return the volume
   */
   public double volume()
   {
      volume = height * width * depth;
      return volume;
   }
   
   /**
      Gets the surface area of this box.
      @return the surface area
   */
   public double surfaceArea()
   {
      surfaceArea = 2 * (height * depth + height * width + depth * width);
      return surfaceArea;
   }
}