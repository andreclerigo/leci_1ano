// YOU SHOULD NOT CHANGE THIS FILE
// NÃO DEVE ALTERAR ESTE FICHEIRO

// UPLOAD TO: http://some.stuff.here/bla.bla/605276

import static java.lang.System.*;
import java.util.Random;

public class TestLinkedList
{

  final static Random rnd = new Random();  // A random number generator

  public static void main(String[] args)
  {
    // Set the random number generator seed if there is an argument
    if (args.length > 0) rnd.setSeed(args[0].hashCode());

    LinkedList<Integer> lst = new LinkedList<Integer>();

    for(int i=0; i<7; i++) {
      lst.addFirst(i);
      lst.addFirst(rnd.nextInt(8));
      lst.addLast(100+i);
    }

    out.println(lst.toString());

    out.println(lst.count(5));

    out.println(lst.indexOf(5));

    out.println(lst.indexOf(5000));

    out.println(lst.cloneReplace(5, 99));  //.toString() implícito!

    out.println(lst.cloneSublist(7, 14));

    out.println(lst.cloneExceptSublist(7, 14));

    lst.removeSublist(7, 14);
    out.println(lst);
    out.println(lst.size());

    lst.removeSublist(12, 14);
    out.println(lst);
    out.println(lst.size());
    out.println(lst.last());

  }   

}