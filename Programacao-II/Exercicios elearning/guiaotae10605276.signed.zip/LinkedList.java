// NMEC: 
// NOME:

public class LinkedList<E> {

   private Node<E> first = null;
   private Node<E> last = null;
   private int size = 0;

   /** {@code LinkedList} constructor, empty so far.
    */
   public LinkedList() { }

   /** Returns the number of elements in the list.
    * @return Number of elements in the list
    */
   public int size() { return size; }

   /** Checks if the list is empty.
    * @return   {@code true} if list empty, otherwise {@code false}.
    */
   public boolean isEmpty() { return size == 0; }

   /** Returns the first element in the list.
    * @return   First element in the list
    */
   public E first() {
      assert !isEmpty(): "empty!";

      return first.elem;
   }

   /** Returns the last element in the list.
    * @return Last element in the list
    */
   public E last() {
      assert !isEmpty(): "empty!";

      return last.elem;
   }

   /** Adds the given element to the start of the list.
    * @param e the element to add
    */
   public void addFirst(E e) {
      first = new Node<>(e, first);
      if (isEmpty())
         last = first;
      size++;

      assert !isEmpty(): "empty!";
      assert first().equals(e) : "wrong element";
   }

   /** Adds the given element to the end of the list.
    * @param e the element to add
    */
   public void addLast(E e) {
      Node<E> newest = new Node<>(e);
      if (isEmpty())
         first = newest;
      else
         last.next = newest;
      last = newest;
      size++;

      assert !isEmpty(): "empty!";
      assert last().equals(e) : "wrong element";
   }

   /** Removes the first element in the list.
    */
   public void removeFirst() {
      assert !isEmpty(): "empty!";
      first = first.next;
      size--;
      if (isEmpty())
         last = null;
   }

   /** Removes all elements.
    */
   public void clear() {
      first = last = null;
      size = 0;
   }

   /** Returns a string representing the list contents.
    * @return A string representing the list contents
    */
   public String toString() {
      String sep = "";
      String s = "";
      for (Node<E> n = first; n != null; n = n.next) {
         s += sep + n.elem;
         sep = ", ";
      }
      return "[" + s + "]";
   }

   /// COMPLETE the functions below.

   /** Count and return number of elements equal to e in this list.
    *  Conta e devolve o número de elementos iguais a e nesta lista.
    */
   public int count(E e) {
      return countR(first, e, 0);
   }
   
   public int countR(Node<E> n, E e, int cont){
      if(n.elem == e) cont++;
      if(n == last) return cont;
      return countR(n.next, e, cont);
   }

   /** Find the position of an element in the list.
    * @param   e an element
    * @return Position of the first occurrence of the element in the list
    */
   public int indexOf(E e) {
      return indexOfR(first, e, 0);
   }
   
   public int indexOfR(Node<E> n, E e, int index){
      if(n.elem == e) return index;
      return indexOfR(n.next, e, index++);
   }

   /** Clone with replacement.
    */
   public LinkedList<E> cloneReplace(E x, E y) { 
      return cloneReplaceR(first, x, y);
   }
   
   public LinkedList<E> cloneReplaceR(Node<E> n, E x, E y){
      Node<E> node = new Node<E>(y, n.next);
      if(n.elem == x){
         n = node;
      }
      return cloneReplaceR(n.next, x, y);
   }

   /** Clone a sublist.
    * @param   start start index of the sublist
    * @param   end    end index of the sublist
    * @return a new list with elements in positions {@code start} 
    *             to {@code end-1}
    */
   public LinkedList<E> cloneSublist(int start, int end) { 
      return cloneSublistR(first, start, end);
   }
   
   public LinkedList<E> cloneSublistR(Node<E> n, int start, int end){
      assert 0<=start && start<=end;
      
      LinkedList<E> lst;
      if(n == null){
         assert start>=0 && end==0;
         lst = new LinkedList<>();
      } else if (start > 0){
         lst = cloneSublistR(n.next, 0, end-1);
      } else {
         lst = cloneSublistR(n.next, 0, end-1);
         lst.addFirst(n.elem);
      }
      return lst;
   }

   /** Clone the complement of a sublist.
    * @param   start start index of a sublist
    * @param   end    end index of a sublist
    * @return a new list with all elements except those in 
    *             positions from {@code start} to {@code end-1}
    */
   public LinkedList<E> cloneExceptSublist(int start, int end) { 
      LinkedList<E> lst = new LinkedList<>();
      cloneR(first, 0, start, end, lst);
      return lst;
   }
   
   void cloneR(Node<E> n, int i, int s, int e, LinkedList<E> lst){
      if(n != null){
         cloneR(n.next, i+1, s, e,lst);
         if(!(s<=i && i<e)){
            lst.addFirst(n.elem);
         }
      }
   }

   /** Removes all elements in positions from {@code start} to {@code end-1}.
    * @param   start start index
    * @param   end    end index
    */
   public void removeSublist(int start, int end) { 
      //removeSublistR(first, start, end);
      System.out.print("ola");
   }
   
   //public void removeSublistR(Node<E> n, start, end){
      
   //}

}