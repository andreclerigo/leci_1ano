/**
   A salary to which a bonus can be applied.
*/
public class Salary{
   double value;
   
   public Salary(double valor){
      value =  valor;
   }
   
   public void applyBonus(double bonus){
      value = this.value * (1 + bonus);
   }
   
   public double getValue(){
      return value;
   }
}