/**
   A square is a rectangle whose sides have the same length.
*/
public class Square
{
   private double length;
   
   /**
      Constructs a square with a given side length.
      @param sideLength the length of each side
   */   
   public Square(double sideLength)
   {
      // your work here
      length = sideLength;
   }
   
   /**
      Returns the area of this square.
      @return the area
   */
   public double area()
   {
      // your work here
      
      return length*length;
   }
   
   /**
      Grows the side length of this square.
      @param percentage the percentage by which to grow the square (for example,
      10 if the square is to be grown by 10%).
   */
   public void grow(double percentage)
   {
      // your work here
      double incrementa;
      incrementa = 1 + (percentage/100);
      
      length = this.length * incrementa;
   }

   // This method is used for checking your work. Do not modify it.

   public static double check(double s, double p)
   {
      Square sq = new Square(s);
      sq.grow(p);
      return sq.area();
   }
}