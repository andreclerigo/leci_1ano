import static java.lang.System.*;

public class P2
{
  public static void main(String[] args)
  {
     assert args.length > 0;
     
     for(int i=0; i<args.length; i++){
        String invertida = recursiva(args[i], "", 0);
        System.out.println(args[i] + " -> " + invertida);
     }
   }
  
  public static String recursiva(String s, String numbers, int i){
     if(i>s.length()-1) return "";
     
     char c = s.charAt(i);

     if(Character.isDigit(c)){
        numbers = c + numbers;
        
        if(i == s.length()-1 || !Character.isDigit(s.charAt(i+1))){
           return numbers + recursiva(s, "", i+1);
        }
        
        return recursiva(s, numbers, i+1);
     }else {
        return c + recursiva(s, "", i+1);
     }
 }
}