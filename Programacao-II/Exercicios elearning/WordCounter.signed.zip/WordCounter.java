import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

/**
   Reads a text file, line by line,
   counts the number of words per line,
   prints out each line of the poem,
   preceded by number of the number of words in that line.
*/
public class WordCounter
{
   public static void main(String[] args) throws FileNotFoundException
   {
      // Set up the input and output file names
      String inputFileName = "JackJill.txt";
      String outputFileName = "output.txt";
      
      File fin = new File(inputFileName);
      File fout = new File(outputFileName);

      // Construct the Scanner and PrintWriter objects
      Scanner scf = new Scanner (fin);
      PrintWriter pw = new PrintWriter(fout);
      
      // your work here
      String linha = "";

      // Read the input file, writing the output for each line
      while (scf.hasNextLine()){
         linha = scf.nextLine();
         String[] w = linha.split(" ");
         int words = w.length;
         
         if (linha.equals("")){
           words = 0;
         }
         pw.printf("%d  %s \n", words, linha);
      }
      // your work here

      // Close all files
      scf.close();
      pw.close();
            
      // your work here
      
      
   }
}